ADM AR Studio project package

Import kembali ZIP ini melalui menu Import Proyek.
File targets.mind disertakan jika pernah diimpor.
Gambar target yang diunggah bukan otomatis menjadi targets.mind; file mind harus dibuat menggunakan compiler target MindAR.
